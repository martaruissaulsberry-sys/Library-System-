// implementing a basic library system in Java. The program should allow users to add books to the library, borrow books, and return books. The system should also maintain a record of each book's available quantity.
// Implement all the getter and setter methods and define them public, Implement a default constructor, Implement a parameterized constructor that has 5 parameters to be used to initialize those 5 member variables, Create a member method named “printBookInfo()”, which prints a specific book's info.

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private String isbn;
    private int totalQuantity;
    private int availableQuantity;

    // Default constructor
    public Book() {
        this.title = "";
        this.author = "";
        this.isbn = "";
        this.totalQuantity = 0;
        this.availableQuantity = 0;
    }

    // Parameterized constructor
    public Book(String title, String author, String isbn, int totalQuantity, int availableQuantity) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.totalQuantity = totalQuantity;
        this.availableQuantity = availableQuantity;
    }

    // Getter and Setter methods
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(int totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public int getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(int availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    // Method to print book information
    public void printBookInfo() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("ISBN: " + isbn);
        System.out.println("Total Quantity: " + totalQuantity);
        System.out.println("Available Quantity: " + availableQuantity);
    }
}

// addBook()—This method creates a new Book object and adds it to the main inventory. It can be implemented using either an ArrayList or LinkedList.
// borrowBook() – This method handles the borrowing process by removing a book from the main inventory and adding it to the lending inventory.
// returnBook() – This method processes book returns by moving the book from the lending inventory back to the main inventory.
// printAll() – This method iterates over the book collection (ArrayList or LinkedList) and calls the printBookInfo() method from the Book class to display details of each book.
// searchByTitle(String title) – method in the Inventory class. It should iterate through the book list and return all books with matching or partially matching titles (case-insensitive)

class Inventory {
    private final List<Book> mainInventory;
    private final List<Book> lendingInventory;

    // Default constructor
    public Inventory() {
        mainInventory = new ArrayList<>();
        lendingInventory = new ArrayList<>();
    }

    // Method to add a book to the main inventory
    public void addBook(Book book) {
        mainInventory.add(book);
    }

    // Method to borrow a book from the main inventory
    public boolean borrowBook(String isbn) {
        for (Book book : mainInventory) {
            if (book.getIsbn().equals(isbn) && book.getAvailableQuantity() > 0) {
                book.setAvailableQuantity(book.getAvailableQuantity() - 1);
                lendingInventory.add(book);
                return true; // Successfully borrowed
            }
        }

        return false; // Book not available
    }

    // Method to return a book to the main inventory
    public boolean returnBook(String isbn) {
        for (Book book : lendingInventory) {
            if (book.getIsbn().equals(isbn)) {
                book.setAvailableQuantity(book.getAvailableQuantity() + 1);
                lendingInventory.remove(book);
                return true; // Successfully returned
            }
        }
        return false; // Book not found in lending inventory
    }

    // Method to print all books in the main inventory
    public void printAll() {
        for (Book book : mainInventory) {
            book.printBookInfo();
            System.out.println("--------------------");
        }
    }

    // Method to search for books by title
    public List<Book> searchByTitle(String title) {
        List<Book> matchingBooks = new ArrayList<>();
        for (Book book : mainInventory) {
            if (book.getTitle().toLowerCase().contains(title.toLowerCase())) {
                matchingBooks.add(book);
            }
        }
        return matchingBooks;
    }
}

public class LibrarySystem {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        try (Scanner scanner = new Scanner(System.in)) {
            boolean running = true;
            while (running) {
                System.out.println("\n1. Add Book\t3. Return Book\t5. Print All Books");
                System.out.println("2. Borrow Book\t4. Search by Title\t6. Exit");
                System.out.print("Choose an option: ");

                if (!scanner.hasNextLine()) {
                    break;
                }

                String choice = scanner.nextLine().trim();
                try {
                    switch (choice) {
                        case "1" -> {
                            System.out.print("Title: ");
                            String title = scanner.nextLine();
                            System.out.print("Author: ");
                            String author = scanner.nextLine();
                            System.out.print("ISBN: ");
                            String isbn = scanner.nextLine();
                            System.out.print("Total quantity: ");
                            int quantity = Integer.parseInt(scanner.nextLine().trim());
                            if (quantity < 0) {
                                System.out.println("Quantity cannot be negative.");
                                break;
                            }
                            inventory.addBook(new Book(title, author, isbn, quantity, quantity));
                            System.out.println("Book added.");
                        }
                        case "2" -> {
                            System.out.print("ISBN to borrow: ");
                            System.out.println(inventory.borrowBook(scanner.nextLine().trim())
                                    ? "Book borrowed."
                                    : "Book not available.");
                        }
                        case "3" -> {
                            System.out.print("ISBN to return: ");
                            System.out.println(inventory.returnBook(scanner.nextLine().trim())
                                    ? "Book returned."
                                    : "No borrowed copy found with that ISBN.");
                        }
                        case "4" -> {
                            System.out.print("Title to search: ");
                            List<Book> matches = inventory.searchByTitle(scanner.nextLine().trim());
                            if (matches.isEmpty()) {
                                System.out.println("No matching books found.");
                            } else {
                                for (Book match : matches) {
                                    match.printBookInfo();
                                    System.out.println("--------------------");
                                }
                            }
                        }
                        case "5" -> {
                            inventory.printAll();
                        }
                        case "6" -> {
                            running = false;
                            System.out.println("Goodbye.");
                        }
                        default -> {
                            System.out.println("Invalid option. Choose 1 through 6.");
                        }
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Please enter a valid whole number for the quantity.");
                }
            }
        }
    }
}
